package com.example.product.Service;
import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import com.example.product.Entity.Category;
import com.example.product.Repository.Categoryrepository;
import com.example.product.exception.ResourceNotFoundException;

@Service
public class Categoryservice {

	@Autowired
	 private Categoryrepository catrepo;

    public Page<Category> getAllCategories(Pageable pageable) {
        return catrepo.findAll(pageable);
    }
    public Category createCategory(Category category) {
        return catrepo.save(category);
    }
    public Category getCategoryById(Long categoryId) {
        return catrepo.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", categoryId));
    }

    public Category updateCategory(Long categoryId, Category categoryDetails) {
        Category category = catrepo.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", categoryId));
        category.setName(categoryDetails.getName());
        
        return catrepo.save(category);
    }

    public void deleteCategory(Long categoryId) {
        Category category = catrepo.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "id", categoryId));
        catrepo.delete(category);
    }
}

