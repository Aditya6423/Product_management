package com.example.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductMangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductMangementApplication.class, args);
	}

}
