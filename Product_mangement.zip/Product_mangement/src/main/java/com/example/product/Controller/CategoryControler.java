package com.example.product.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.product.Entity.Category;
import com.example.product.Service.Categoryservice;



@RestController
@RequestMapping("/api/categories")
public class CategoryControler {

	 @Autowired
	    private Categoryservice categoryService;
	 
	 @GetMapping
	    public ResponseEntity<Page<Category>> getAllCategories(Pageable pageable) {
	        return ResponseEntity.ok().body(categoryService.getAllCategories(pageable));
	    }
	 @PostMapping
	    public ResponseEntity<Category> createCategory(@RequestBody Category category) {
	        return ResponseEntity.ok().body(categoryService.createCategory(category));
	    }
	 @GetMapping("/{id}")
	    public ResponseEntity<Category> getCategoryById(@PathVariable(value = "id") Long categoryId) {
	        return ResponseEntity.ok().body(categoryService.getCategoryById(categoryId));
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<Category> updateCategory(@PathVariable(value = "id") Long categoryId,
	                                                    @RequestBody Category categoryDetails) {
	        return ResponseEntity.ok().body(categoryService.updateCategory(categoryId, categoryDetails));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteCategory(@PathVariable(value = "id") Long categoryId) {
	        categoryService.deleteCategory(categoryId);
	        return ResponseEntity.ok().build();
	    }
	    
}
